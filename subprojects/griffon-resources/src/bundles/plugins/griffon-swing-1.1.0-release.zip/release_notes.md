### Fixes

 * [GRIFFON-517][1] Default imports for Swing Views are applied to JavaFX views
   Default imports affecting Swing Views were moved out of core, into the Swing plugin

[1] https://jira.codehaus.org/browse/GRIFFON-517
