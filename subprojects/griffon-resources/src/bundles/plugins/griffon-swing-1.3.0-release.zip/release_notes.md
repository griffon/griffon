### New Features

 * Support action interceptors
 * Refactored PropertyEditors with latest support fro Griffon 1.3.0

