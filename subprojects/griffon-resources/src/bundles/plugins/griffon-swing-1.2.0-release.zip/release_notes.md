### New Features

 * Support new I18N API
 * Added PropertyEditors for common AWT and Swing classes
 * Support ActionManager feature

