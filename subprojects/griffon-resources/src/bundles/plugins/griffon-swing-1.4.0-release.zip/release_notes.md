### New Features

 * Support action interceptors
 * Refactored PropertyEditors with latest support for Griffon 1.3.0

