### Fixes

 * GRIFFON-641 applet fails to load due to MPE when setting `resourceResolver`.

