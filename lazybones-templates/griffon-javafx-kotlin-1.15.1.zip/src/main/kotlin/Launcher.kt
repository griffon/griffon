package ${project_package}

import griffon.javafx.JavaFXGriffonApplication

fun main(args: Array<String>) {
    JavaFXGriffonApplication.main(args)
}