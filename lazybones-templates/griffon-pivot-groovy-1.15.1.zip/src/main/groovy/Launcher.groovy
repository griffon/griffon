package ${project_package}

import griffon.pivot.DesktopPivotGriffonApplication

class Launcher {
    static void main(String[] args) throws Exception {
        DesktopPivotGriffonApplication.run(args)
    }
}