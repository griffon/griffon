package ${project_package};

import griffon.lanterna.LanternaGriffonApplication;

public class Launcher {
    public static void main(String[] args) throws Exception {
        LanternaGriffonApplication.run(LanternaGriffonApplication.class, args);
    }
}