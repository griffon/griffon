Basic Griffon Plugin project
----------------------------

You have just created a basic Griffon Plugin project. The project has the
following file structure

    .
    ├── README.md
    ├── build.gradle
    ├── config
    ├── gradle
    └── subprojects
        ├── plugin
        │   └── src
        │       ├── main
        │       │   └── java
        │       └── test
        │           └── resources
        └── guide
            └── src
                ├── asciidoc
                ├── javadoc
                └── resources

