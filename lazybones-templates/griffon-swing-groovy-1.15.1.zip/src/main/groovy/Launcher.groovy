package ${project_package}

import griffon.swing.SwingGriffonApplication

class Launcher {
    static void main(String[] args) throws Exception {
        SwingGriffonApplication.run(SwingGriffonApplication, args)
    }
}