package ${project_package};

import griffon.pivot.DesktopPivotGriffonApplication;

public class Launcher {
    public static void main(String[] args) throws Exception {
        DesktopPivotGriffonApplication.run(args);
    }
}