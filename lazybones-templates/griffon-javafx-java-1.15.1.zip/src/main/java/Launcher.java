package ${project_package};

import griffon.javafx.JavaFXGriffonApplication;

public class Launcher {
    public static void main(String[] args) throws Exception {
        JavaFXGriffonApplication.main(args);
    }
}