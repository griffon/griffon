package ${project_package};

import griffon.swing.SwingGriffonApplication;

public class Launcher {
    public static void main(String[] args) throws Exception {
        SwingGriffonApplication.run(SwingGriffonApplication.class, args);
    }
}