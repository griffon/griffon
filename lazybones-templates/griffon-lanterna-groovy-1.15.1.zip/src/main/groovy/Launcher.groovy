package ${project_package}

import griffon.lanterna.LanternaGriffonApplication

class Launcher {
    static void main(String[] args) throws Exception {
        LanternaGriffonApplication.run(LanternaGriffonApplication, args)
    }
}